
from django.urls import path
from . import views  # Make sure to import views from the same app

urlpatterns = [
    path('login', views.login_view, name='login'),  # Points to the login view
]
