from django.contrib import admin
from django.urls import path, include
from main import views  # import views from the main app

urlpatterns = [
    path('admin/', admin.site.urls),
    path('login/', views.login_view, name='login'),  # The login view path
    path('', include('main.urls')),  # Include the URLs from the 'main' app
]
